package com.geneinsure.QualityCallMonitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QualityCallMonitoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
