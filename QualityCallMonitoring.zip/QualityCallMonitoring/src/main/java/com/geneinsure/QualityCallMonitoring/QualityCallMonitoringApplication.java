package com.geneinsure.QualityCallMonitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QualityCallMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(QualityCallMonitoringApplication.class, args);
	}

}
