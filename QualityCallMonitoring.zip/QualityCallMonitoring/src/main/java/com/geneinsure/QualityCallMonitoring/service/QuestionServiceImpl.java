/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.geneinsure.QualityCallMonitoring.service;
import com.geneinsure.QualityCallmonitoring.entity.Question;
import com.geneinsure.QualityCallMonitoring.repository.QuestionRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author "Tana"
 */
@Service
public class QuestionServiceImpl implements QuestionService{

    
}
