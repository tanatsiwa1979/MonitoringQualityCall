/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.geneinsure.QualityCallMonitoring.model;

import lombok.Data;

/**
 *
 * @author "Tana"
 */
@Data
public class QuestionType {
private String questiongrpType;
    
}
