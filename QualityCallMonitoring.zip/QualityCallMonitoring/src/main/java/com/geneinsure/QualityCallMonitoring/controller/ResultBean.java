/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.geneinsure.QualityCallMonitoring.controller;

import java.io.Serializable;
import javax.inject.Named;
import javax.faces.bean.ViewScoped;
/**
 *
 * @author "Tana"
 */
@Named
@ViewScoped
public class ResultBean implements Serializable{
    
}
